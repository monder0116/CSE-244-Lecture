typedef struct{
	double shiftElapsed;
	double convElapsed;
	float result1;
	float result2;
	pid_t cliendPid;
	int requestNum;
}MatrixResultsType;